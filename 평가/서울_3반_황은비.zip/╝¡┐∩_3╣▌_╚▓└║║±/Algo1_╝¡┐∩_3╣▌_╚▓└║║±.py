T = int(input())

for tc in range(1, T+1):
    N = int(input())
    arr = [list(map(int, input().split())) for _ in range(N)]

    di = [0, 1, 0, -1]
    dj = [1, 0, -1, 0]

    bonus_list = []

    for i in range(N):
        for j in range(N):
            bonus_score = 0
            if i == 0 or i == N-1 or j == 0 or j == N-1:    # 가장자리 칸은 점수 없음
                continue
            else:                                           # 행렬 내부 값이라면
                for k in range(4):
                    bonus_score += arr[i+di[k]][j+dj[k]]    # 상하좌우 값을 더하고

                bonus_score -= arr[i][j]                # 맞힌 칸의 점수를 뺌

                if bonus_score < 0:                     # 보너스 점수가 음수면
                    bonus_score = 0                     # 0점
                elif bonus_score % 2 == 0:
                    bonus_score *= 2                    # 이때 보너스 점수가 짝수면 두배

                bonus_list.append(bonus_score)

    bonus_list.sort()
    print(f'#{tc} {bonus_list[-1]}')
