T = int(input())

for tc in range(1, T+1):
    N, K = list(map(int, input().split()))
    arr = list(map(int, input().split()))

    location = 0              # 개구리의 현재 위치
    val = []                  # 개구리가 밟은 연잎의 숫자들
    val.append(arr[0])        # 시작점 연잎 숫자 기록하고 시작

    for _ in range(K+1):                                        # 점프 횟수만큼 반복할건데
        if 0 <= location < N and arr[location] > 0:             # 현재 위치가 연잎 범위이고, 연잎 숫자가 양수일 때
            if val[-1] < 0:                                     # 직전에 뛴 값이 음수라면(뒤로 뛰었는지 확인)
                location = location + arr[location] - val[-1]   # 직전에 뒤로 간 칸만큼 더 앞으로 간다.
                val.append(arr[location])                       # 이동 후 연잎 숫자 기록
            else:
                location += arr[location]                       # 직전에 뛴 값이 없거나, 양수라면 해당 수만큼 앞으로 간다.
                val.append(arr[location])                       # 이동 후 연잎 숫자 기록

        elif 0 <= location < N and arr[location] < 0:           # 현재 위치가 연잎 범위인데, 연잎 숫자가 음수라면
            location += arr[location]                           # 해당 수만큼 뒤로 간다.
            if location < 0:                                    # 이때 현재 위치가 연잎 범위를 벗어나면
                break                                           # 그 즉시 중단
            else:
                val.append(arr[location])
            # 이동 후 연잎 숫자 기록


        else:                                                   # 현재 위치가 연잎 범위가 아니라면
            break                                               # 더 이상 점프 하지 않는다.


    print(f'#{tc} {sum(val) - val[0]}')

